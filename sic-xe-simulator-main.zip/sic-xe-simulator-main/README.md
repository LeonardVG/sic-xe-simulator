# sic-xe-simulator
Computador hipotético baseado na  arquitetura do livro :Sytems Software: An Introduction to System  Programming; Leland L. Beck
